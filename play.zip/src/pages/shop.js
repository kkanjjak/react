import { Link } from 'react-router-dom';
import Product from '../product'

function Shop(){
    return(
        <div>
            <Link to='/'><button style={{margin: 10, width: 60, height: 30,fontSize: 15, backgroundColor:'tomato', border:'none', borderRadius: 10, color:'white'}}>홈으로</button></Link>
            <h1 style={{fontSize: 40, textAlign: 'center'}}>쟈부리몰</h1>
            <hr/>
            <div style={{display: 'flex', flexDirection: 'row', justifyContent: 'center', width: 1100, marginLeft:'auto', marginRight: 'auto'}}>
            <Product src="https://t1.daumcdn.net/thumb/R1280x0.fjpg/?fname=http://t1.daumcdn.net/brunch/service/user/Jp6/image/P0k0dJYAgotLKzaSYsJ-kMzCoBA.jpg" name='갈비탕' />
            <Product src="http://gwchild826.firstmall.kr/data/goods/1/2021/06/42676_tmp_621873870e9ae37ddb1cd601ec6aa8668882large.jpg" name='닭갈비' />
            <Product src="https://img-cf.kurly.com/shop/data/goodsview/20220429/gv40000308690_1.jpg" name='김치찌개' />
            <Product src="https://homecuisine.co.kr/files/attach/images/140/971/074/295cae2795a6c2f7ab30694e66af729e.JPG" name='제육볶음' />
            <Product src="https://img-cf.kurly.com/shop/data/goodsview/20211105/gv00000240132_1.jpg" name='순대곱창' />

            </div>
        </div>
    );
}

export default Shop;