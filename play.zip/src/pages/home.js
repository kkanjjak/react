import { Link } from 'react-router-dom';
import '../App.css';
import Button from '../Button';
import { useState } from 'react';

function Home() {
  const [hello, setHello] = useState('')
  const [e, setE] = useState(false)
  function onSubmit(event){
    event.preventDefault();
    console.log(event)
    setHello(event.target[0].value);
    setE((current) => !current)

  }

  return (
    <div>
      <Link to={'/shop'}><Button value='쇼핑몰'/></Link>
      {e ? <h1>HI, {hello}~~🖐</h1>: <div><form onSubmit={onSubmit}><input type='text' defaultValue={hello} onChange={() => console.log(hello)}  style={{height: 30, margin: 10}} placeholder="WHAT'S YOUR NAME?" /><Button value='Submit' /></form></div>}
      {console.log(e)}
    </div>

  );
}

export default Home;
