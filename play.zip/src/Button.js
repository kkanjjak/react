function Button({value}){
    return(
        <button style={{width: 80, height: 40, fontSize: 20, border: 'none', borderRadius: 10, backgroundColor: 'tomato', color: 'white', margin: 10}}>{value}</button>
    )
}

export default Button;