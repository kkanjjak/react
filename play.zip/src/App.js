import logo from './logo.svg';
import './App.css';
import Button from './Button';
import { useState } from 'react';
import Home from './pages/home';
import Shop from './pages/shop';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

function App() {

  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/shop' element={<Shop />} />

    </Routes>
    </BrowserRouter>
  );
}

export default App;
