function Product({name, src}){
    return(
        <div style={{display: 'flex', flexDirection: 'column', alignItems:'center',marginLeft: 30}}>
            <img src={src} style={{objectFit:'cover',width: 250, height: 280, border: '1px, solid, black', marginTop:30}} />
            <div style={{marginTop: 10, fontSize: 20}}>{name}</div>
        </div>
    )
}

export default Product;